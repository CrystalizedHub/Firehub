<?php
/** RESELLER — fully editable rows, see config/site.php ($RESELLER). */
$reseller_url = trim((string)($RESELLER['contact'] ?? ''));
$buy_href     = $reseller_url !== '' ? $reseller_url : discord_url();
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Resellers</h1>
        <p class="page-sub"><?= e($RESELLER['intro'] ?? '') ?></p>
    </div>
</section>

<section class="section tight-top">
    <div class="container">
        <?php if (!empty($RESELLER['rows'])): ?>
            <!-- reseller rows (edit in config/site.php) -->
            <div class="offer-grid">
                <?php foreach ($RESELLER['rows'] as $row): ?>
                <div class="offer-card reveal">
                    <h3><?= e($row['name'] ?? '') ?></h3>
                    <span class="offer-price"><?= e($row['price'] ?? '—') ?></span>
                    <?php if (!empty($row['note'])): ?><p class="offer-note"><?= e($row['note']) ?></p><?php endif; ?>
                    <a class="btn btn-ghost offer-btn" href="<?= e($buy_href) ?>" <?= $buy_href[0] !== '#' && $buy_href !== url('discord') ? 'target="_blank" rel="noopener"' : '' ?>>Contact on Discord</a>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty">no resellers right now. join the <a class="link" href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>discord</a> and ask around.</div>
        <?php endif; ?>

        <div class="notice reveal" style="margin-top:20px; max-width:720px;">
            <p>want to resell firehub? open a ticket in the discord and ask.</p>
        </div>
    </div>
</section>
