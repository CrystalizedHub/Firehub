<?php
/** 404 — page not found. */
?>
<section class="discord-hero">
    <div class="container">
        <h1 class="page-title">404</h1>
        <p class="lead center">This page doesn't exist — it may have been moved or removed.</p>
        <div class="btn-row center">
            <a class="btn btn-primary" href="<?= e(url('')) ?>">Back home</a>
            <a class="btn btn-ghost" href="<?= e(url('script')) ?>">View scripts</a>
        </div>
    </div>
</section>
