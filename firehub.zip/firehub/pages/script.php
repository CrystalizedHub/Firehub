<?php
/** SCRIPT — all supported games with copyable loaders. */
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Script</h1>
        <p class="page-sub">
            same loader for every game. free with a key, plans skip it.
        </p>
        <div class="universal-box reveal">
            <?php codebox($SCRIPT); ?>
            <?php key_cta('block'); ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if (!$GAMES): ?>
            <div class="empty">No games yet — add them in <strong>config/site.php</strong>.</div>
        <?php else: ?>
            <div class="game-grid">
                <?php foreach ($GAMES as $g):
                    $g_script = (string)($g['script'] ?? $SCRIPT);
                ?>
                <article class="game-card reveal">
                    <div class="game-head">
                        <img class="game-icon" src="<?= e(asset('img/games/' . $g['slug'] . '.png')) ?>"
                             alt="<?= e($g['name']) ?> icon" width="64" height="64" loading="lazy"
                             onerror="this.src='<?= e(asset('img/games/placeholder.png')) ?>';this.onerror=null;">
                        <div class="game-id-block">
                            <h3><?= e($g['name']) ?></h3>
                            <a class="chip" href="https://www.roblox.com/games/<?= e($g['id']) ?>"
                               target="_blank" rel="noopener">ID <?= e($g['id']) ?></a>
                        </div>
                    </div>
                    <p class="game-desc"><?= e($g['desc']) ?></p>
                    <?php codebox($g_script); ?>
                    <?php key_cta('block'); ?>
                </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
