<?php
/** MEDIA — gallery of images, videos and GIFs with a lightbox. */
$has_video = false; $has_gif = false; $has_image = false;
foreach ((array)$MEDIA as $m) {
    if ($m['type'] === 'video') $has_video = true;
    if ($m['type'] === 'gif')   $has_gif = true;
    if ($m['type'] === 'image') $has_image = true;
}
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Media</h1>
        <p class="page-sub">screenshots and clips. click one to zoom.</p>
        <?php if (!empty($CREATOR['enabled'])): ?>
        <div class="notice creator-box reveal">
            <p class="creator-title"><?= e($CREATOR['title']) ?></p>
            <p><?= e($CREATOR['text']) ?></p>
            <p class="creator-rate"><?= e($CREATOR['rate']) ?></p>
            <p class="creator-apply"><?= e($CREATOR['apply']) ?> <a href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>join discord</a> &middot; <a href="<?= e(url('owner')) ?>">owner</a></p>
        </div>
        <?php endif; ?>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if (!$MEDIA): ?>
            <div class="empty">nothing posted yet. clips and screenshots land here later — join the <a class="link" href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>discord media channel</a> meanwhile.</div>
        <?php else: ?>
            <div class="filter-row" id="mediaFilter">
                <button class="chip-btn active" type="button" data-filter="all">All</button>
                <?php if ($has_image): ?><button class="chip-btn" type="button" data-filter="image">Images</button><?php endif; ?>
                <?php if ($has_video): ?><button class="chip-btn" type="button" data-filter="video">Videos</button><?php endif; ?>
                <?php if ($has_gif): ?><button class="chip-btn" type="button" data-filter="gif">GIFs</button><?php endif; ?>
            </div>

            <div class="media-grid" id="mediaGrid">
                <?php foreach ($MEDIA as $i => $m): ?>
                <figure class="media-item reveal" data-type="<?= e($m['type']) ?>" data-index="<?= (int)$i ?>">
                    <div class="media-thumb">
                        <?php if ($m['type'] === 'video'): ?>
                            <video src="<?= e(media_src($m['src'])) ?>" preload="metadata" muted loop playsinline
                                <?= !empty($m['poster']) ? 'poster="' . e(media_src($m['poster'])) . '"' : '' ?>></video>
                            <span class="play-badge" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>
                            </span>
                        <?php else: ?>
                            <img src="<?= e(media_src($m['src'])) ?>" alt="<?= e($m['title'] ?? 'Media') ?>" loading="lazy">
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($m['title'])): ?>
                        <figcaption><?= e($m['title']) ?></figcaption>
                    <?php endif; ?>
                </figure>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
