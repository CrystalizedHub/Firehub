<?php
/** PRICES / PLANS — same page, reachable at both /prices and /plans. */
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Prices</h1>
        <p class="page-sub">free with a key. plans skip the key. buying goes through tickets in the discord.</p>
    </div>
</section>

<section class="section tight-top">
    <div class="container">
        <?php if (!$PLANS): ?>
            <div class="empty">No plans yet — add them in <strong>config/site.php</strong>.</div>
        <?php else: ?>
            <div class="plans-grid">
                <?php foreach ($PLANS as $p): ?>
                <div class="plan reveal<?= !empty($p['featured']) ? ' featured' : '' ?>">
                    <?php if (!empty($p['featured'])): ?><span class="plan-badge">Best value</span><?php endif; ?>
                    <span class="plan-name"><?= e($p['duration']) ?></span>
                    <span class="plan-price"><?= e($p['price']) ?></span>
                    <?php if (!empty($p['note'])): ?><span class="plan-note"><?= e($p['note']) ?></span><?php endif; ?>
                    <a class="btn <?= !empty($p['featured']) ? 'btn-primary' : 'btn-ghost' ?> plan-btn"
                       href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>buy</a>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="pricing-info reveal">
            <div class="notice">
                <p><?= e($PRICING_INFO['main'] ?? '') ?><?php mention($SITE['buyer_role_id'], 'role') ?><?= e($PRICING_INFO['mid'] ?? '') ?><?php mention($SITE['buyer_chat_id'], 'channel') ?><?= e($PRICING_INFO['end'] ?? '') ?></p>
            </div>
            <div class="notice">
                <p><?= e($PRICING_INFO['ticket'] ?? '') ?> <?php mention($SITE['ticket_channel_id'], 'channel') ?></p>
            </div>
        </div>
    </div>
</section>
