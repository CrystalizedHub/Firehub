<?php
/** GET KEY — key system page. Link is $SITE['key_url'] in config/site.php. */
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Get key</h1>
        <p class="page-sub">free. runs through linkvertise + loot labs, takes like a minute.</p>
        <div class="key-hero reveal">
            <?php key_cta(); ?>
        </div>
    </div>
</section>

<section class="section tight-top">
    <div class="container">
        <div class="section-head">
            <h2>how it works</h2>
        </div>
        <ol class="steps">
            <li class="reveal">
                <h3>click get key</h3>
                <p>opens the key system in a new tab</p>
            </li>
            <li class="reveal d1">
                <h3>click through the steps</h3>
                <p>linkvertise, loot labs and a couple more. just click through them</p>
            </li>
            <li class="reveal d2">
                <h3>grab your key</h3>
                <p>the loader asks for it in game. paste and run</p>
            </li>
        </ol>

        <div class="notice reveal" style="margin-top:32px; max-width:720px;">
            <p><strong>keys are hwid locked.</strong> one key = one device. sharing your key = blacklist, no second chances.</p>
        </div>
        <div class="notice reveal" style="margin-top:12px; max-width:720px;">
            <p>key not working or got blacklisted by mistake? open a ticket in <?php mention($SITE['ticket_channel_id'], 'channel') ?></p>
        </div>
    </div>
</section>
