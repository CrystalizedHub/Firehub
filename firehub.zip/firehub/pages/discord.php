<?php
/** DISCORD — join link + how buying works. */
?>
<section class="discord-hero">
    <div class="container">
        <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="72" height="72" class="reveal">
        <h1 class="reveal d1">Join the discord</h1>
        <p class="lead center reveal d2">
            buying, support, updates. it all happens here.
        </p>
        <div class="btn-row center reveal d3">
            <a class="btn btn-primary btn-lg" href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>join discord</a>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <h2>How buying works</h2>
        </div>
        <ol class="steps">
            <li class="reveal">
                <h3>open a ticket</h3>
                <p>join the discord and hit up <?php mention($SITE['ticket_channel_id'], 'channel') ?></p>
            </li>
            <li class="reveal d1">
                <h3>say your plan</h3>
                <p>tell staff what you want and pay</p>
            </li>
            <li class="reveal d2">
                <h3>get your stuff</h3>
                <p>you get the <?php mention($SITE['buyer_role_id'], 'role') ?> role and <?php mention($SITE['buyer_chat_id'], 'channel') ?></p>
            </li>
        </ol>
    </div>
</section>
