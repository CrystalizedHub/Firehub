<?php
/** OWNER — the person behind FireHub. Edit details in config/site.php ($OWNER). */
?>
<section class="page-head">
    <div class="container">
        <h1 class="page-title">Owner</h1>
        <p class="page-sub">the dev</p>
    </div>
</section>

<section class="section tight-top">
    <div class="container">
        <div class="owner-wrap reveal">
            <div class="owner-card">
                <img class="owner-banner" src="<?= e(asset('img/' . $OWNER['banner'])) ?>" alt="Owner banner">
                <div class="owner-body">
                    <img class="owner-avatar" src="<?= e(asset('img/' . $OWNER['avatar'])) ?>" alt="<?= e($OWNER['name']) ?>">
                    <h2 class="owner-name"><?= e($OWNER['name']) ?></h2>
                    <span class="owner-role"><?= e($OWNER['role']) ?></span>
                    <?php if (!empty($OWNER['bio'])): ?><p class="owner-bio"><?= e($OWNER['bio']) ?></p><?php endif; ?>
                    <div class="owner-actions">
                        <a class="btn btn-primary" href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>message me</a>
                        <button class="btn btn-ghost" type="button" data-copy="<?= e($OWNER['discord']) ?>">copy username</button>
                    </div>
                </div>
            </div>

            <div class="notice owner-notice">
                <p>need me directly? join the discord and open a ticket in <?php mention($SITE['ticket_channel_id'], 'channel') ?></p>
            </div>
        </div>
    </div>
</section>
