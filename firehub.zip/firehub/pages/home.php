<?php
/** HOME — plain and blunt. No marketing sections. */
$game_names = array_column($GAMES, 'name');
$hero_list  = implode(', ', array_slice($game_names, 0, 3));
$more_count = max(0, count($game_names) - 3);
?>

<section class="hero">
    <div class="container hero-grid">
        <div class="hero-copy reveal">
            <h1>Every game.<br>One loader.</h1>
            <p class="lead">
                firehub works on <?= e($hero_list) ?><?= $more_count > 0 ? ' + ' . $more_count . ' more' : '' ?>.
                free with a key, or buy a plan and skip the key system.
            </p>
            <div class="btn-row">
                <a class="btn btn-primary" href="<?= e(url('getkey')) ?>">get key</a>
                <a class="btn btn-ghost" href="<?= e(url('prices')) ?>">buy a plan</a>
                <a class="btn btn-ghost" href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>join discord</a>
            </div>
        </div>

        <div class="hero-code reveal d1">
            <?php codebox($SCRIPT); ?>
            <div class="key-hero" style="text-align:center"><?php key_cta(); ?></div>
            <p class="code-hint">one loadstring, every game</p>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <h2>Games</h2>
            <a class="link" href="<?= e(url('script')) ?>">all scripts &rarr;</a>
        </div>
        <?php if (!$GAMES): ?>
            <div class="empty">no games yet. add them in <strong>config/site.php</strong>.</div>
        <?php else: ?>
            <div class="game-strip">
                <?php foreach ($GAMES as $g): ?>
                    <a class="game-tile reveal" href="<?= e(url('script')) ?>">
                        <img src="<?= e(asset('img/games/' . $g['slug'] . '.png')) ?>" alt="" loading="lazy"
                             onerror="this.src='<?= e(asset('img/games/placeholder.png')) ?>';this.onerror=null;">
                        <span class="game-tile-name"><?= e($g['name']) ?></span>
                        <span class="game-tile-id">ID <?= e($g['id']) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="container">
        <div class="section-head">
            <h2>How to run</h2>
        </div>
        <ol class="steps">
            <li class="reveal">
                <h3>get a key</h3>
                <p>free, or buy a plan to skip it</p>
            </li>
            <li class="reveal d1">
                <h3>copy the loader</h3>
                <p>from above or any game card</p>
            </li>
            <li class="reveal d2">
                <h3>execute</h3>
                <p>paste it in your executor and run it</p>
            </li>
        </ol>
        <p class="home-note">questions? <a href="<?= e(discord_url()) ?>" <?= !discord_invite_missing() ? 'target="_blank" rel="noopener"' : '' ?>>join the discord</a>.</p>
    </div>
</section>
