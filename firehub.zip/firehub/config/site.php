<?php
/* =====================================================================
   FIREHUB — SITE CONFIG
   Everything you will ever want to change lives in this file.
   You should almost never need to touch the other files.
   ===================================================================== */

/* ---------------------------------------------------------------------
   GENERAL
   --------------------------------------------------------------------- */
$SITE = [

    // Site name (used in the navbar, titles, footer)
    'name'    => 'FireHub',

    // If the site is NOT hosted at the domain root (e.g. firehub.lol/site/),
    // set the folder here, e.g. '/site'. Otherwise leave ''.
    'base_path' => '',

    // Your domain — used for the CNAME file + sitemap when building
    // the static version (php build.php).
    'domain' => 'firehub.lol',

    // ---------------------------------------------------------------
    // DISCORD INVITE — PASTE YOUR REAL INVITE LINK HERE
    // e.g. 'https://discord.gg/yourcode'
    // While it is empty, every "join / buy" button points to the
    // Discord page and a small setup note is shown to you.
    // ---------------------------------------------------------------
    'discord_invite' => 'https://discord.gg/firescript',

    // Discord IDs shown as text mentions (from your Discord copy)
    'buyer_role_id'    => '1568689010929311775', // role buyers get
    'buyer_chat_id'    => '1570404971130785802', // buyer chat channel
    'ticket_channel_id'=> '1566027906415722608', // ticket channel

    // Names shown inside the Discord-style mention chips.
    // SET THESE TO YOUR REAL ROLE / CHANNEL NAMES (Discord shows names, not IDs).
    'buyer_role_name'     => 'buyer',       // renders as  @buyer
    'buyer_chat_name'     => 'buyer-chat',  // renders as  #buyer-chat
    'ticket_channel_name' => 'tickets',     // renders as  #tickets

    // Key system link — shown as a "get key" button under every loadstring.
    // Leave '' to hide the button.
    'key_url' => 'https://jnkie.com/get-key/firescript',
];

/* ---------------------------------------------------------------------
   THE SCRIPT / LOADER
   Shown on the Home and Script pages. One loader for every game.
   (Per-game overrides are possible — see $GAMES below.)
   --------------------------------------------------------------------- */
$SCRIPT = 'loadstring(game:HttpGet("https://jnkie.com/loaders/firehub"))()';

/* ---------------------------------------------------------------------
   GAMES (cards on the Script page, strip on the Home page)

   How to add a game:
     1. Copy one block below and fill in name / id / desc.
     2. Drop a square icon at  assets/img/games/YOUR-SLUG.png
        (slug must match 'slug' below — no icon? it falls back to a
        placeholder, so the site never breaks).
   To remove a game, just delete its block.

   Optional per-game fields:
     'script' => '...'   // custom loader for this game only
   --------------------------------------------------------------------- */
$GAMES = [

    [
        'name' => 'Fisch',
        'slug' => 'fisch',
        'id'   => '16732694052',
        'desc' => 'auto cast, shake & reel, events',
    ],
    [
        'name' => 'Throw Food for Animals',
        'slug' => 'throw-food-for-animals',
        'id'   => '120219252362013',
        'desc' => 'auto throw, animal farm, cash',
    ],
    [
        'name' => 'Kukirin Life',
        'slug' => 'kukirin-life',
        'id'   => '122840796290491',
        'desc' => 'auto cash, tricks, levels',
    ],
    [
        'name' => 'Urban Reload',
        'slug' => 'urban-reload',
        'id'   => '84448037861644',
        'desc' => 'combat + farm helpers',
    ],
    [
        'name' => 'Survive Your Ideas',
        'slug' => 'survive-your-ideas',
        'id'   => '77900175935766',
        'desc' => 'auto survive, round helpers',
    ],
    [
        'name' => 'Fust Survival',
        'slug' => 'fust-survival',
        'id'   => '79862723087324',
        'desc' => 'farm, craft, raid tools',
    ],
];

/* ---------------------------------------------------------------------
   PLANS (Prices / Plans page)

   'featured' => true  makes a plan stand out (Lifetime below).
   Prices are plain text — write them exactly as they should show.
   --------------------------------------------------------------------- */
$PLANS = [
    ['duration' => '1 Day',    'price' => '€0.50', 'note' => ''],
    ['duration' => '3 Days',   'price' => '€1.25', 'note' => ''],
    ['duration' => '7 Days',   'price' => '€2.50', 'note' => ''],
    ['duration' => '14 Days',  'price' => '€4.75', 'note' => ''],
    ['duration' => '30 Days',  'price' => '€6.50', 'note' => ''],
    ['duration' => 'Lifetime', 'price' => '€8.50', 'note' => 'pay once, keep it', 'featured' => true],
];

/* ---------------------------------------------------------------------
   PRICING PAGE INFO
   The Discord mentions are rendered as text chips (they can't work
   on a website) — the IDs come from $SITE above.
   --------------------------------------------------------------------- */
$PRICING_INFO = [
    'main'   => 'a plan kills the key system. you also get the ',
    'mid'    => ' role and ',
    'end'    => ' once you join the discord.',
    'ticket' => 'to buy one, open a ticket in ',
];

/* ---------------------------------------------------------------------
   CREATOR DEAL (box on the Media page — recruiting video makers)
   Set 'enabled' => false to hide the box.
   --------------------------------------------------------------------- */
$CREATOR = [
    'enabled' => true,
    'title'   => 'we are hiring content creators',
    'text'    => 'make videos on firehub. you get paid + a lifetime key + a role in our discord.',
    'rate'    => '5.000 views = €7 — more views, more pay',
    'apply'   => 'join the discord to apply, or message the owner.',
];

/* ---------------------------------------------------------------------
   OWNER (Owner page)
   --------------------------------------------------------------------- */
$OWNER = [
    'name'     => 'devsleepy___',
    'role'     => 'Owner & Developer',
    'bio'      => 'made firehub. keeps the loaders updated.',
    'avatar'   => 'owner/avatar.png',   // square image/gif
    'banner'   => 'owner/banner.gif',   // wide banner image/gif
    'discord'  => 'devsleepy___',       // Discord username (copy button)
];

/* ---------------------------------------------------------------------
   RESELLER (Reseller page)
   Plain editable rows — change names, prices and notes freely.
   Add or remove rows as your reseller lineup changes.

   'price' is free text ("€5", "€4 / key", "—", whatever you need).
   --------------------------------------------------------------------- */
$RESELLER = [
    'title' => 'Buy from a reseller',
    'intro' => 'resellers sell firehub keys on discord. same thing, sometimes faster.',

    // Optional: a different Discord link just for reseller purchases.
    // Leave '' to use the main Discord invite.
    'contact' => '',

    // ----- EDIT THE ROWS BELOW (leave empty to show "coming soon") -----
    'rows' => [
        // [
        //     'name'  => 'Reseller #1',
        //     'price' => '€5 / key',
        //     'note'  => 'Instant delivery, always in stock.',
        // ],
    ],
];

/* ---------------------------------------------------------------------
   MEDIA (Media page)

   Each item:  'type' => 'image' | 'video' | 'gif'
               'src'  => path inside assets/media/ (or a full URL)
               'title'=> optional caption

   Videos can optionally have  'poster' => path-to-preview-image.

   Add a screenshot? Drop the file into assets/media/ and add one
   line below — that's it. No other files need touching.
   --------------------------------------------------------------------- */
// Empty for now — clips/screenshots from the media channel get added later.
$MEDIA = [
    // Add an item by dropping the file into assets/media/ and adding a line:
    // ['type' => 'image', 'src' => 'my-shot.png',  'title' => 'caption'],
    // ['type' => 'gif',   'src' => 'my-clip.gif'],
    // ['type' => 'video', 'src' => 'clip.mp4', 'poster' => 'clip-poster.png'],
];
