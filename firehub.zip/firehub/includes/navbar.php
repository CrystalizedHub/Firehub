<?php
/** Main navigation — order here = order on screen. 'class' = extra styling. */
$NAV_ITEMS = [
    ['key' => 'script',   'label' => 'Script'],
    ['key' => 'getkey',   'label' => 'Get Key', 'class' => 'nav-cta'],
    ['key' => 'media',    'label' => 'Media'],
    ['key' => 'prices',   'label' => 'Prices'],
    ['key' => 'discord',  'label' => 'Discord'],
    ['key' => 'reseller', 'label' => 'Reseller'],
    ['key' => 'owner',    'label' => 'Owner'],
];
?>
<header class="nav" id="nav">
    <div class="container nav-inner">
        <a class="brand" href="<?= e(url('')) ?>">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="26" height="26">
            <span>Fire<em>Hub</em></span>
        </a>

        <nav class="nav-links" aria-label="Main navigation">
            <?php foreach ($NAV_ITEMS as $item): ?>
                <a href="<?= e(url($item['key'])) ?>" class="<?= e($item['class'] ?? '') ?><?= $ROUTE === $item['key'] ? ' active' : '' ?>"><?= e($item['label']) ?></a>
            <?php endforeach; ?>
        </nav>

        <button class="nav-burger" id="navBurger" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="mobileMenu">
            <span></span><span></span><span></span>
        </button>
    </div>

    <div class="mobile-menu" id="mobileMenu">
        <nav class="mobile-links" aria-label="Mobile navigation">
            <?php foreach ($NAV_ITEMS as $item): ?>
                <a href="<?= e(url($item['key'])) ?>" class="<?= e($item['class'] ?? '') ?><?= $ROUTE === $item['key'] ? ' active' : '' ?>"><?= e($item['label']) ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>
