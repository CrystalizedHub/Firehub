<footer class="footer">
    <div class="container footer-inner">
        <div class="footer-brand">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="20" height="20">
            <span>Fire<em>Hub</em></span>
        </div>
        <nav class="footer-links" aria-label="Footer">
            <a href="<?= e(url('script')) ?>">Script</a>
            <a href="<?= e(url('getkey')) ?>">Get Key</a>
            <a href="<?= e(url('prices')) ?>">Prices</a>
            <a href="<?= e(url('media')) ?>">Media</a>
            <a href="<?= e(url('discord')) ?>">Discord</a>
            <a href="<?= e(url('owner')) ?>">Owner</a>
        </nav>
        <small>firehub &copy; <?= date('Y') ?> &middot; not affiliated with roblox</small>
    </div>
</footer>

<script src="<?= e(asset('js/main.js')) ?>" defer></script>
</body>
</html>
