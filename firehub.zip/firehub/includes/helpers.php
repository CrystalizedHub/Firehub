<?php
/* Small shared helpers used across the site. */

/** HTML-escape a value. */
function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/** Build a site URL that respects $SITE['base_path']. */
function url(string $path = ''): string
{
    global $SITE;
    $base = rtrim((string)($SITE['base_path'] ?? ''), '/');
    return $base . '/' . ltrim($path, '/');
}

/** Build an assets/ URL. */
function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

/**
 * Resolve a media file path from config. Accepts any of these:
 *   'assets/media/clip.mp4'   'media/clip.mp4'   'clip.mp4'   'https://...'
 */
function media_src(string $src): string
{
    if (preg_match('#^(https?://|/)#i', $src)) {
        return $src;
    }
    if (str_starts_with($src, 'assets/')) {
        return asset(substr($src, 7));
    }
    if (str_starts_with($src, 'media/')) {
        return asset($src);
    }
    return asset('media/' . ltrim($src, '/'));
}

/** Where every "join Discord" / "buy" button should point. */
function discord_url(): string
{
    global $SITE;
    $inv = trim((string)($SITE['discord_invite'] ?? ''));
    if ($inv !== '' && $inv[0] !== '#') {
        return $inv;
    }
    return url('discord');
}

/** True while the Discord invite is still empty (shows setup hints). */
function discord_invite_missing(): bool
{
    global $SITE;
    $inv = trim((string)($SITE['discord_invite'] ?? ''));
    return $inv === '' || $inv[0] === '#';
}

/** Cheapest plan price, formatted — used for the home page CTA line. */
function min_plan_price(string $fallback = 'See plans'): string
{
    global $PLANS;
    $min = null;
    foreach ((array)$PLANS as $p) {
        if (preg_match('/([\d]+(?:[.,][\d]+)?)/', (string)($p['price'] ?? ''), $m)) {
            $v = (float)str_replace(',', '.', $m[1]);
            if ($min === null || $v < $min) {
                $min = $v;
            }
        }
    }
    return $min === null ? $fallback : '€' . number_format($min, 2);
}

/** Render the shared code box with a Copy button. */
function codebox(string $code, string $lang = 'Lua'): void
{
    ?>
    <div class="codebox">
        <div class="codebar">
            <span class="code-lang"><?= e($lang) ?></span>
            <button class="copy-btn" type="button" data-copy="<?= e($code) ?>">Copy</button>
        </div>
        <pre><code><?= e($code) ?></code></pre>
    </div>
    <?php
}

/** Big, separate "get key" button. $style: '' | 'block' (full width) | 'center'. */
function key_cta(string $style = ''): void
{
    global $SITE;
    $key = trim((string)($SITE['key_url'] ?? ''));
    if ($key === '') {
        return;
    }
    $class = 'key-cta' . ($style !== '' ? ' ' . $style : '');
    ?>
    <a class="<?= e($class) ?>" href="<?= e($key) ?>" target="_blank" rel="noopener">get key</a>
    <?php
}

/**
 * Render a Discord-style mention chip (@role / #channel).
 * Shows the NAME like Discord does, links to the Discord server.
 */
function mention(string $id, string $kind = 'channel'): void
{
    global $SITE;

    if ($kind === 'role') {
        $name = (string)($SITE['buyer_role_name'] ?? 'buyer');
    } else {
        $map = [
            (string)($SITE['buyer_chat_id'] ?? '')     => (string)($SITE['buyer_chat_name'] ?? 'buyer-chat'),
            (string)($SITE['ticket_channel_id'] ?? '') => (string)($SITE['ticket_channel_name'] ?? 'tickets'),
        ];
        $name = $map[(string)$id] ?? 'channel';
    }

    $prefix = $kind === 'role' ? '@' : '#';
    echo '<a class="mention" href="' . e(discord_url()) . '"' . (!discord_invite_missing() ? ' target="_blank" rel="noopener"' : '') . ' title="Discord ID: ' . e($id) . '">' . e($prefix . $name) . '</a>';
}
