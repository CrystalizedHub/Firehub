<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($PAGE_TITLE) ?></title>
    <meta name="description" content="<?= e($PAGE_DESC_S) ?>">
    <meta name="theme-color" content="#060607">
    <meta property="og:title" content="<?= e($PAGE_TITLE) ?>">
    <meta property="og:description" content="<?= e($PAGE_DESC_S) ?>">
    <meta property="og:type" content="website">
    <link rel="icon" href="<?= e(asset('img/logo.png')) ?>" type="image/png">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
</head>
<body>
