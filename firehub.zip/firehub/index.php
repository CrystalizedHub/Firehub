<?php
/* =====================================================================
   FIREHUB — FRONT CONTROLLER
   All clean routes (/script, /prices, ...) are handled here.
   Requires Apache + .htaccess (included) or the nginx snippet in the
   README. Static assets are served directly.
   ===================================================================== */

require __DIR__ . '/config/site.php';
require __DIR__ . '/includes/helpers.php';

/* --- Let the PHP built-in dev server serve static files directly --- */
if (php_sapi_name() === 'cli-server') {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
    $base = trim((string)($SITE['base_path'] ?? ''), "/ \t\n\r");
    if ($base !== '' && strpos($path, '/' . $base . '/') === 0) {
        $path = substr($path, strlen('/' . $base));
    }
    $file = __DIR__ . ($path === '/' ? '/index.php' : $path);
    if ($path !== '/' && is_file($file) && pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
        return false; // serve the asset as-is
    }
}

/* --- Resolve the route --- */
$route = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/', '/');
$base  = trim((string)($SITE['base_path'] ?? ''), "/ \t\n\r");
if ($base !== '' && strpos($route, $base) === 0) {
    $route = trim(substr($route, strlen($base)), '/');
}
$route = preg_replace('#^index\.php/?#', '', $route);

$ROUTE_MAP = [
    ''        => 'home',
    'home'    => 'home',
    'script'  => 'script',
    'getkey'  => 'getkey',
    'media'   => 'media',
    'prices'  => 'prices',
    'plans'   => 'prices',   // /plans renders the same page as /prices
    'discord' => 'discord',
    'reseller'=> 'reseller',
    'owner'   => 'owner',
];

$PAGE  = $ROUTE_MAP[$route] ?? null;
$ROUTE = $route; // used for navbar active state (so /plans highlights "Plans")
if ($PAGE === null) {
    http_response_code(404);
    $PAGE  = '404';
    $ROUTE = '404';
}

/* --- Page meta --- */
$PAGE_DESC = [
    'home'     => 'FireHub — a Roblox script hub. One loader for every supported game.',
    'script'   => 'Every game FireHub supports, with a one-click copy loader for each.',
    'media'    => 'Screenshots, clips and GIFs from FireHub.',
    'prices'   => 'FireHub plans and pricing — from €0.50 to lifetime access.',
    'discord'  => 'Join the FireHub Discord for purchases, tickets and support.',
    'reseller' => 'Buy FireHub keys from resellers.',
    '404'      => 'Page not found.',
];
$PAGE_NAME = [
    'home' => 'Roblox script hub', 'script' => 'Script', 'getkey' => 'Get Key', 'media' => 'Media',
    'prices' => 'Prices & Plans', 'discord' => 'Discord', 'reseller' => 'Reseller', '404' => 'Not found',
];

$SITE_NAME   = (string)$SITE['name'];
$PAGE_TITLE  = $SITE_NAME . ' — ' . ($PAGE_NAME[$PAGE] ?? 'Roblox script hub');
$PAGE_DESC_S = (string)($PAGE_DESC[$PAGE] ?? $PAGE_DESC['home']);

require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/navbar.php';

echo '<main class="site-main">';
require __DIR__ . '/pages/' . $PAGE . '.php';
echo '</main>';

require __DIR__ . '/includes/footer.php';
