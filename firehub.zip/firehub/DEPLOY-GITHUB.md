# Deploy FireHub on GitHub Pages + Porkbun

The `static-site/` folder is plain HTML — no PHP needed. GitHub Pages hosts it
free, Porkbun just points the domain at it.

## 1. Push to GitHub

1. Make a GitHub repo.
   - Easiest: name it `<your-username>.github.io` → site serves at the root.
   - A normal repo name also works (e.g. `firehub`) as long as you connect
     firehub.lol (step 3) — the domain makes it serve at the root.
2. Upload the **contents** of `static-site/` to the repo (index.html must sit
   in the repo root, not inside a subfolder).
   - GitHub web upload, or:
     ```bash
     cd static-site
     git init
     git add .
     git commit -m "firehub"
     git branch -M main
     git remote add origin https://github.com/YOURNAME/YOURREPO.git
     git push -u origin main
     ```
3. In the repo: **Settings → Pages** → Source: *Deploy from a branch* →
   branch `main`, folder `/ (root)` → Save.
4. While you're in Settings → Pages, type `firehub.lol` under **Custom
   domain** and save. (The included `CNAME` file already contains it, so it
   sticks.)

## 2. Connect Porkbun (DNS)

In Porkbun → your domain → DNS records, set:

| Type  | Host | Value                 |
|-------|------|-----------------------|
| A     | (blank) | 185.199.108.153   |
| A     | (blank) | 185.199.109.153   |
| A     | (blank) | 185.199.110.153   |
| A     | (blank) | 185.199.111.153   |
| CNAME | www | YOURNAME.github.io.   |

(Porkbun may pre-create parked A records — delete those first.)

Back in GitHub Settings → Pages, wait for the DNS check to pass, then
**Enforce HTTPS**. Done — https://firehub.lol serves your site.

## 3. Updating the site later

The static files are generated from `config/site.php`. Workflow:

1. Edit `config/site.php` (games, prices, links, media…)
2. Rebuild — needs PHP on your PC (`php build.php`), or just ask me to
   rebuild and hand you a fresh `static-site/`.
3. Push the new `static-site/` contents to GitHub. Pages redeploys
   automatically in ~1 minute.

## Notes

- Clean URLs work: `/script`, `/prices`, `/getkey`, … GitHub Pages serves
  each folder's `index.html`.
- `404.html` is included → GitHub uses it automatically for bad URLs.
- `.nojekyll` is included (disables GitHub's Jekyll step so nothing breaks).
- `sitemap.xml` + `CNAME` are pre-generated for firehub.lol.
- If you'd rather host the PHP version: any PHP host (cPanel etc.) — upload
  the whole `firehub/` folder instead. Don't mix: GitHub Pages can't run PHP.
