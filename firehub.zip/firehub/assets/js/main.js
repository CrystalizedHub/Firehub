/* ============================================================
   FIREHUB — main.js
   Nav, copy buttons, media filters + lightbox, reveal-on-scroll.
   No dependencies.
   ============================================================ */
(function () {
    'use strict';

    /* ---------- navbar scroll state ---------- */
    var nav = document.getElementById('nav');
    function onScroll() {
        if (nav) nav.classList.toggle('scrolled', window.scrollY > 8);
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    /* ---------- mobile menu ---------- */
    var burger = document.getElementById('navBurger');
    var menu = document.getElementById('mobileMenu');

    function closeMenu() {
        if (!burger || !menu) return;
        burger.classList.remove('open');
        menu.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
        burger.setAttribute('aria-label', 'Open menu');
        document.body.classList.remove('nav-open');
    }

    if (burger && menu) {
        burger.addEventListener('click', function () {
            var open = !menu.classList.contains('open');
            burger.classList.toggle('open', open);
            menu.classList.toggle('open', open);
            burger.setAttribute('aria-expanded', String(open));
            burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
            document.body.classList.toggle('nav-open', open);
        });
        menu.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', closeMenu);
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeMenu();
        });
        window.addEventListener('resize', function () {
            if (window.innerWidth > 860) closeMenu();
        });
    }

    /* ---------- copy buttons ---------- */
    document.querySelectorAll('[data-copy]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var text = btn.getAttribute('data-copy') || '';
            var original = btn.getAttribute('data-label') || btn.textContent || 'Copy';
            btn.setAttribute('data-label', original);

            function done(ok) {
                btn.classList.add('copied');
                btn.textContent = ok ? 'Copied' : 'Press Ctrl+C';
                clearTimeout(btn._resetTimer);
                btn._resetTimer = setTimeout(function () {
                    btn.classList.remove('copied');
                    btn.textContent = original;
                }, 1600);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () { done(true); }, function () { fallback(); });
            } else {
                fallback();
            }

            function fallback() {
                var ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.focus();
                ta.select();
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
                ta.remove();
                done(ok);
            }
        });
    });

    /* ---------- reveal on scroll (subtle) ---------- */
    var reveals = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add('in');
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.08, rootMargin: '0px 0px -24px 0px' });
        reveals.forEach(function (el) { io.observe(el); });
    } else {
        reveals.forEach(function (el) { el.classList.add('in'); });
    }

    /* ---------- media filters ---------- */
    var filterRow = document.getElementById('mediaFilter');
    if (filterRow) {
        var chips = filterRow.querySelectorAll('.chip-btn');
        var items = document.querySelectorAll('#mediaGrid .media-item');
        chips.forEach(function (chip) {
            chip.addEventListener('click', function () {
                chips.forEach(function (c) { c.classList.remove('active'); });
                chip.classList.add('active');
                var f = chip.getAttribute('data-filter');
                items.forEach(function (it) {
                    var show = f === 'all' || it.getAttribute('data-type') === f;
                    it.classList.toggle('hidden', !show);
                });
            });
        });
    }

    /* ---------- lightbox ---------- */
    var items = document.querySelectorAll('.media-item');
    if (items.length) {
        // collect sources from the DOM (stays in sync with filters)
        var entries = [];
        items.forEach(function (it) {
            var video = it.querySelector('video');
            var img = it.querySelector('img');
            if (video) {
                entries.push({ type: 'video', src: video.getAttribute('src'), title: capText(it) });
            } else if (img) {
                entries.push({ type: 'image', src: img.getAttribute('src'), title: capText(it) });
            }
        });

        function capText(it) {
            var fc = it.querySelector('figcaption');
            return fc ? fc.textContent : '';
        }

        var lb = document.createElement('div');
        lb.className = 'lightbox';
        lb.setAttribute('role', 'dialog');
        lb.setAttribute('aria-label', 'Media viewer');
        lb.innerHTML =
            '<button class="lb-btn lb-close" type="button" aria-label="Close">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
            '</button>' +
            '<button class="lb-btn lb-prev" type="button" aria-label="Previous">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>' +
            '</button>' +
            '<div class="lb-content"></div>' +
            '<button class="lb-btn lb-next" type="button" aria-label="Next">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>' +
            '</button>' +
            '<div class="lb-caption"></div>';
        document.body.appendChild(lb);

        var lbContent = lb.querySelector('.lb-content');
        var lbCaption = lb.querySelector('.lb-caption');
        var lbPrev = lb.querySelector('.lb-prev');
        var lbNext = lb.querySelector('.lb-next');
        var current = -1;

        function show(i) {
            current = (i + entries.length) % entries.length;
            var en = entries[current];
            lbContent.innerHTML = '';

            if (en.type === 'video') {
                var v = document.createElement('video');
                v.src = en.src;
                v.controls = true;
                v.autoplay = true;
                v.loop = true;
                v.playsInline = true;
                lbContent.appendChild(v);
                var p = v.play();
                if (p && p.catch) p.catch(function () {});
            } else {
                var im = document.createElement('img');
                im.src = en.src;
                im.alt = en.title || 'Media';
                lbContent.appendChild(im);
            }
            lbCaption.textContent = en.title || '';
            lb.classList.add('open');
            document.body.classList.add('nav-open'); // lock scroll
            lbPrev.classList.toggle('hidden', entries.length < 2);
            lbNext.classList.toggle('hidden', entries.length < 2);
        }

        function hide() {
            lb.classList.remove('open');
            lbContent.innerHTML = '';
            current = -1;
            document.body.classList.remove('nav-open');
        }

        items.forEach(function (it) {
            it.addEventListener('click', function () {
                var idx = parseInt(it.getAttribute('data-index') || '0', 10);
                show(idx);
            });
        });
        lbPrev.addEventListener('click', function (e) { e.stopPropagation(); show(current - 1); });
        lbNext.addEventListener('click', function (e) { e.stopPropagation(); show(current + 1); });
        lb.querySelector('.lb-close').addEventListener('click', hide);
        lb.addEventListener('click', function (e) {
            if (e.target === lb || e.target === lbContent) hide();
        });
        document.addEventListener('keydown', function (e) {
            if (!lb.classList.contains('open')) return;
            if (e.key === 'Escape') hide();
            if (e.key === 'ArrowLeft' && entries.length > 1) show(current - 1);
            if (e.key === 'ArrowRight' && entries.length > 1) show(current + 1);
        });
    }
})();
