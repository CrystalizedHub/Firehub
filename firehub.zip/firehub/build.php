<?php
/* =====================================================================
   FIREHUB — STATIC SITE BUILDER
   Turns the PHP site into plain HTML for GitHub Pages / Porkbun
   static hosting / Netlify / any static host.

   Usage:  php build.php          → outputs to static-site/  (domain root)
           php build.php /repo    → base path (GitHub project pages)

   Edit config/site.php first, then run this, then push static-site/.
   ===================================================================== */

if (PHP_SAPI !== 'cli') {
    exit("run from the terminal: php build.php\n");
}

$BASE = isset($argv[1]) ? rtrim($argv[1], '/') : '';

require __DIR__ . '/config/site.php';
$SITE['base_path'] = $BASE; // rebuild links with the base path
require __DIR__ . '/includes/helpers.php';

$OUT = __DIR__ . '/static-site';

/* --- route table (keep in sync with index.php) --- */
$ROUTES = [
    ''        => 'home',
    'script'  => 'script',
    'getkey'  => 'getkey',
    'media'   => 'media',
    'prices'  => 'prices',
    'discord' => 'discord',
    'reseller'=> 'reseller',
    'owner'   => 'owner',
    '404'     => '404',
];

$PAGE_DESC = [
    'home'     => 'FireHub — a Roblox script hub. One loader for every supported game.',
    'script'   => 'Every game FireHub supports, with a one-click copy loader for each.',
    'getkey'   => 'Get a free FireHub key — linkvertise + lootlabs, takes a minute.',
    'media'    => 'Screenshots, clips and GIFs from FireHub.',
    'prices'   => 'FireHub plans and pricing — skip the keysystem from €0.50.',
    'discord'  => 'Join the FireHub Discord for purchases, tickets and support.',
    'reseller' => 'Buy FireHub keys from resellers.',
    'owner'    => 'The dev behind FireHub.',
    '404'      => 'Page not found.',
];
$PAGE_NAME = [
    'home' => 'Roblox script hub', 'script' => 'Script', 'getkey' => 'Get Key', 'media' => 'Media',
    'prices' => 'Prices & Plans', 'discord' => 'Discord', 'reseller' => 'Reseller',
    'owner' => 'Owner', '404' => 'Not found',
];

/* --- fresh output dir --- */
function rrmdir(string $dir): void
{
    if (!is_dir($dir)) return;
    foreach (scandir($dir) as $f) {
        if ($f === '.' || $f === '..') continue;
        $p = $dir . '/' . $f;
        is_dir($p) ? rrmdir($p) : unlink($p);
    }
    rmdir($dir);
}
if (is_dir($OUT)) rrmdir($OUT);
mkdir($OUT, 0777, true);

/* --- copy assets recursively --- */
function rcopy(string $src, string $dst): void
{
    mkdir($dst, 0777, true);
    foreach (scandir($src) as $f) {
        if ($f === '.' || $f === '..') continue;
        $s = $src . '/' . $f;
        $d = $dst . '/' . $f;
        is_dir($s) ? rcopy($s, $d) : copy($s, $d);
    }
}
rcopy(__DIR__ . '/assets', $OUT . '/assets');

/* --- render every route to its own folder --- */
foreach ($ROUTES as $route => $page) {
    $PAGE  = $page;
    $ROUTE = $route;
    $SITE_NAME   = (string)$SITE['name'];
    $PAGE_TITLE  = $SITE_NAME . ' — ' . ($PAGE_NAME[$PAGE] ?? '');
    $PAGE_DESC_S = (string)($PAGE_DESC[$PAGE] ?? '');

    ob_start();
    require __DIR__ . '/includes/head.php';
    require __DIR__ . '/includes/navbar.php';
    echo '<main class="site-main">';
    require __DIR__ . '/pages/' . $PAGE . '.php';
    echo '</main>';
    require __DIR__ . '/includes/footer.php';
    $html = (string)ob_get_clean();

    $dir = $route === '' ? $OUT : $OUT . '/' . $route;
    if ($route !== '') mkdir($dir, 0777, true);
    file_put_contents($dir . '/index.html', $html);
    echo "built /" . ($route === '' ? '' : $route . '/') . "\n";
}

/* --- /plans → same as /prices (meta refresh) --- */
mkdir($OUT . '/plans', 0777, true);
$to = url('prices');
file_put_contents($OUT . '/plans/index.html',
    "<!DOCTYPE html>\n<html lang=\"en\"><head><meta charset=\"UTF-8\">"
    . "<meta http-equiv=\"refresh\" content=\"0; url={$to}\">"
    . "<title>FireHub — Prices</title></head>"
    . "<body><p><a href=\"{$to}\">plans moved to prices</a></p></body></html>\n");
echo "built /plans/ (redirect)\n";

/* --- GitHub Pages / general extras --- */
file_put_contents($OUT . '/.nojekyll', '');
file_put_contents($OUT . '/CNAME', (string)$SITE['domain'] . "\n");
// GitHub Pages looks for 404.html at the root
copy($OUT . '/404/index.html', $OUT . '/404.html');

/* --- sitemap --- */
$domain = rtrim((string)$SITE['domain'], '/');
$urls = ['', 'script', 'getkey', 'media', 'prices', 'discord', 'reseller', 'owner'];
$s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
foreach ($urls as $u) {
    $s .= "  <url><loc>https://{$domain}/" . ($u === '' ? '' : $u . '/') . "</loc></url>\n";
}
$s .= "</urlset>\n";
file_put_contents($OUT . '/sitemap.xml', $s);

echo "done → static-site/  (CNAME: {$domain}, .nojekyll, sitemap.xml)\n";
