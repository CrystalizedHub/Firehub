# FireHub Website

Dark, fast, no-dependencies website for the FireHub Roblox script hub.

**Two ways to host:**

- **GitHub Pages / Porkbun / any static host** → use the ready-made
  `static-site/` folder (plain HTML, everything included). Full walkthrough:
  **DEPLOY-GITHUB.md**.
- **PHP hosting** (cPanel etc.) → upload the whole folder as-is.

Regenerate the static version after editing config: `php build.php`
(outputs to `static-site/`, includes CNAME + sitemap for firehub.lol).

---

## 1. Deploy to firehub.lol

1. Zip is ready: upload `firehub.zip` to your host and extract it into
   the folder your domain points at (`public_html/` on most cPanel hosts).
2. Point the domain's DNS A-record at your host, enable the free
   Let's Encrypt SSL, force HTTPS in your panel.
3. That's it. Clean routes work out of the box via the included `.htaccess`:

```
firehub.lol/          home
firehub.lol/script    supported games + loaders
firehub.lol/media     gallery (images / GIFs / videos)
firehub.lol/prices    plans & pricing
firehub.lol/plans     same page as /prices
firehub.lol/discord   join links + ticket info
firehub.lol/reseller  reseller list
```

**Nginx instead of Apache?** Use this instead of `.htaccess`:

```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

**Subfolder instead of root?** Put the folder on your host and set
`'base_path' => '/that-folder'` in `config/site.php`.

---

## 2. Make it yours (one file)

Almost everything lives in **`config/site.php`** — open it, it's commented.

| What                  | Where in config/site.php                  |
|-----------------------|-------------------------------------------|
| Discord invite link   | `$SITE['discord_invite']` (currently empty — paste yours, the setup note vanishes automatically) |
| Script / loader       | `$SCRIPT` (or per-game `'script'` in `$GAMES`) |
| Games (name, ID, icon, description) | `$GAMES` array |
| Plan prices           | `$PLANS` array                            |
| Discord role/channel IDs (text mentions) | `$SITE['buyer_role_id']`, `buyer_chat_id`, `ticket_channel_id` |
| Reseller rows         | `$RESELLER['rows']`                       |
| Media gallery         | `$MEDIA` array                            |

### Add a game
1. Drop a square icon at `assets/img/games/your-slug.png`
2. Add a block to `$GAMES`:

```php
[
    'name' => 'Your Game',
    'slug' => 'your-slug',          // = icon filename without .png
    'id'   => '1234567890',         // Roblox place ID
    'desc' => 'Short description.',
],
```

Missing icon? A placeholder shows automatically — the site never breaks.

### Add media (screenshot / GIF / clip)
1. Drop the file into `assets/media/`
2. Add one line to `$MEDIA`:

```php
['type' => 'image', 'src' => 'my-screenshot.png', 'title' => 'Caption'],
['type' => 'gif',   'src' => 'clip.gif'],
['type' => 'video', 'src' => 'clip.mp4', 'poster' => 'poster.png'], // optional poster
```

Full URLs (`https://...`) also work. Clicking any item opens a lightbox
with prev/next arrows, keyboard arrows and Escape — no extra pages.

### Resellers
Edit `$RESELLER['rows']` in `config/site.php`. `price` is free text, so
you can write `€5 / key`, `3 for €12`, whatever. Add or remove rows freely.
Set `$RESELLER['contact']` if resellers should use a different Discord link.

---

## 3. File map

```
firehub/
├── index.php              front controller (all routes)
├── .htaccess              clean URLs for Apache
├── config/
│   └── site.php           ★ everything you edit lives here
├── includes/
│   ├── head.php           <head> / meta
│   ├── navbar.php         nav (desktop + mobile burger)
│   ├── footer.php         footer
│   └── helpers.php        small shared functions
├── pages/                 one file per page
│   ├── home.php  script.php  media.php  owner.php
│   ├── prices.php  discord.php  reseller.php  404.php
└── assets/
    ├── css/style.css      all styling (design tokens at the top)
    ├── js/main.js         copy buttons, menu, lightbox, reveals
    └── img/  media/       icons, game images, screenshots
```

**Colors:** edit `--accent` (and `--accent-2`) at the top of
`assets/css/style.css` — the whole site follows.

---

## 4. Testing locally

```bash
cd firehub
php -S localhost:8080 index.php    # then open http://localhost:8080
```

The built-in server handles clean routes too, so `/script`, `/prices` etc.
work exactly like on the real host.
